from random import *



# D1 =[1, 2, 3 ,4 ,5, 6]
# D2 =[1, 2, 3 ,4 ,5, 6]
# result = choice(D1)
# print(result)

# résultat1=randint(1,6)
# résultat2=randint(1,6)
# print(résultat1+résultat2)

# resulta = ["ciseaux ", "Caillou ", "Pierre "]
# print(choice(resulta)*5)

# octo = list(range(0, 20, 1))
# octo.append(-3)
# print(octo)

# paycode = dict([
#     ('benoit', 3420), 
#     ('marc', 6543), 
#     ('cedric', 8934), 
#     ('marion', 2152)
# ])

# adresse = dict([
#     ('chateau premier', 12400),
#     ('route deoure', 13400),
#     ('marseille le porc', 13011)
# ])


mol = dict(
    melon=234,
    cerise=12,
    fleur=43
)



# print(paycode)
print(mol)

# for k, v in adresse.items():
#     print(k, v)


for i in range(1, 10, 2):
    print(i)
  


# fruits = ['banane', 'cerise', 'fraise', 'framboise', 'pomme', 'poire', 'pomme']

# fruits.insert(0, 'citron')

# print(fruits)

# fruits.remove('banane')

# print(fruits)

# fruits.sort()

# print(fruits)

# fruits.pop()

# print(fruits)
# fruits[2] = "patate"
# print(fruits)

# compt = [1, 4, 15, 17, 19, 3]

# print(compt)

# compt.sort()
# print(compt)

# square = []
# for x in range(10):
#     square.append(x**4)
#     print(square)

# a = 22
# b = 5
# print((a // b) + (a % b))

# text = "bonjour je veux 238 cerise"
# for caractere in text:
#     if caractere in '123456789':
#         print(caractere)

# for k in range(3, 13, 3):
#     print(k)

# for k in range(5):
#     print(k+1)

