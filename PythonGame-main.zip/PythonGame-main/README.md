# PythonGame

#### Information

```Git clone
https://github.com/MorganLevetti/PythonGame.git 
```
- Python 3.10.6  64bit
- run python file in VisualStudio on main.py
- or run in terminal :

```Run
python3 main.py
```




